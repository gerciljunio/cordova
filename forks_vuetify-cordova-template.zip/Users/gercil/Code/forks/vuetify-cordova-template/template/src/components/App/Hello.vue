<template>
  <v-container fluid fill-height>
    <v-slide-y-transition mode="out-in">
      <v-layout align-center justify-center>

        <v-flex xs12>

          <v-text-field
      label="Name"
      required
    ></v-text-field>

    <br>
          
          <img src="../../../static/img/v.png" alt="Vuetify.js" class="mb-5">
        <blockquote>
          &#8220;First, solve the problem. Then, write the code.&#8221;
          <footer>
            <small>
              <em>&mdash;John Johnson</em>
            </small>
          </footer>
        </blockquote>


        </v-flex>
        
      </v-layout>
    </v-slide-y-transition>
  </v-container>
</template>
