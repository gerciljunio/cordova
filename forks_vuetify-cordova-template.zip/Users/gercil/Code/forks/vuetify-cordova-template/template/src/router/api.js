const base = 'http://site.com.br';

module.exports = {
	login: {
		fb: base+'face'
	}
};